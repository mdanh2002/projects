// CH372UpDownDlg.h : header file
//

#if !defined(AFX_CH372UPDOWNDLG_H__CE5236D3_738D_4FF5_9BCF_96E759F43169__INCLUDED_)
#define AFX_CH372UPDOWNDLG_H__CE5236D3_738D_4FF5_9BCF_96E759F43169__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCH372UpDownDlg dialog
UINT mThreadDown2(LPVOID pParam);
UINT mThreadUp2(LPVOID pParam);
UINT mThreadUp1(LPVOID pParam);

class CCH372UpDownDlg : public CDialog
{
// Construction
public:
	void mCloseWin();
//	UCHAR DeviceName[128];
	BOOL m_trdup1;
	BOOL m_trdup2;
	BOOL m_trddown2;
	BOOL m_open;
	BOOL m_close;
	HANDLE T2DHandle;    //�˵�2�´��豸�򿪾��
	HANDLE T2UHandle;    //�˵�2�ϴ��豸�򿪾��
	HANDLE T1Handle;	 //�˵�1�ϴ��豸�򿪾��

	CCH372UpDownDlg(CWnd* pParent = NULL);	// standard constructor
	UCHAR mCharToBcd(UCHAR iChar );
	PUCHAR mStrtoVal(PUCHAR str, ULONG strlen);
// Dialog Data
	//{{AFX_DATA(CCH372UpDownDlg)
	enum { IDD = IDD_CH372UPDOWN_DIALOG };
	CButton	m_btnup2;
	CButton	m_btndown2;
	CButton	m_btnup1;
	CListBox	m_listup1;
	long	m_uplen1;
	long	m_uplen2;
	CString	m_downdata2;
	long	m_downlen2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCH372UpDownDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCH372UpDownDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton2Down();
	afx_msg void OnButton2Up();
	afx_msg void OnButton1Up();
	afx_msg void OnClose();
	afx_msg void OnOpenCH375Device();
	afx_msg void OnCloseCH375Device();
	afx_msg void OnClearD2Data();
	afx_msg void OnClearU2Data();
	afx_msg void OnClearU1Data();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CH372UPDOWNDLG_H__CE5236D3_738D_4FF5_9BCF_96E759F43169__INCLUDED_)
