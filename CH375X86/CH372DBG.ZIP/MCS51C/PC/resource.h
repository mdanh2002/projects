//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CH37XDBG.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CH37XDBG_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DLGSFR                      129
#define IDD_DLGIRAM                     130
#define IDD_DLGXRAM                     131
#define IDD_DLGEXTERN                   132
#define IDD_DLGENTER                    138
#define IDC_EDIT_NAME1                  1000
#define IDC_EDIT_VALUE1                 1001
#define IDC_EDIT_NAME2                  1002
#define IDC_EDIT_VALUE2                 1003
#define IDC_EDIT_NAME3                  1004
#define IDC_EDIT_VALUE3                 1005
#define IDC_EDIT_NAME4                  1006
#define IDC_EDIT_VALUE4                 1007
#define IDC_EDIT_NAME5                  1008
#define IDC_EDIT_VALUE5                 1009
#define IDC_EDIT_NAME6                  1010
#define IDC_EDIT_VALUE6                 1011
#define IDC_EDIT_NAME7                  1012
#define IDC_EDIT_VALUE7                 1013
#define IDC_EDIT_NAME8                  1014
#define IDC_EDIT_VALUE8                 1015
#define IDC_STATIC_VER                  1016
#define IDC_EDIT_NAME9                  1017
#define IDC_EDIT1                       1018
#define IDC_EDIT_ADDR                   1018
#define IDC_EDIT_BUF                    1018
#define IDC_EDIT_VALUE9                 1018
#define IDC_EDIT_DATA                   1018
#define IDC_EDIT_LEN                    1019
#define IDC_EDIT_NAME10                 1019
#define IDC_EDIT_PARA1                  1020
#define IDC_EDIT_VALUE10                1020
#define IDC_EDIT_PARA2                  1021
#define IDC_EDIT_NAME11                 1021
#define IDC_EDIT_PARA3                  1022
#define IDC_EDIT_VALUE11                1022
#define IDC_EDIT_PARA4                  1023
#define IDC_EDIT_NAME12                 1023
#define IDC_LIST1                       1024
#define IDC_EDIT_VALUE12                1024
#define IDC_BUTTON_SEND                 1025
#define IDC_EDIT_NAME13                 1025
#define IDC_BUTTON_RECEIVE              1026
#define IDC_EDIT_VALUE13                1026
#define IDC_EDIT_COMM                   1027
#define IDC_EDIT_NAME14                 1027
#define IDC_IGRID                       1028
#define IDC_EDIT_VALUE14                1028
#define IDC_EDIT_NAME15                 1029
#define IDC_XGRID                       1030
#define IDC_EDIT_VALUE15                1030
#define IDC_BUTTON_REFRESH              1031
#define IDC_BUTTON_READ                 1032
#define IDC_EDIT_NAME16                 1032
#define IDC_EDIT_VALUE16                1033
#define IDC_BUTTON_ENTER                1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
