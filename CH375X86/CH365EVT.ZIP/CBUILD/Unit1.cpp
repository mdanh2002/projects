//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

      #include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        if ( LoadLibrary( "CH365DLL.DLL" ) == NULL )  // ����DLLʧ��,����δ��װ��ϵͳ��
          {
                  Application->MessageBox("�޷�����CH365��DLL", "information", MB_ICONSTOP | MB_OK );

          }

         else if ( CH365mOpenDevice( 0,TRUE,TRUE ) < 0 ) // ʹ��֮ǰ������豸
                   Application->MessageBox("��CH365�豸", "information", MB_OK );

          else
          {
                  Application->MessageBox( "�޷���CH365�豸", "information", MB_OK );

          }
}
//---------------------------------------------------------------------------
 
